#include <iostream>
#include <string>
#include <vector>

class Student {
private:
    int rollNumber;
    std::string name;
    int age;

public:
    Student(int roll, const std::string& studentName, int studentAge)
        : rollNumber(roll), name(studentName), age(studentAge) {}

    int getRollNumber() const {
        return rollNumber;
    }

    void displayInfo() const {
        std::cout << "Roll Number: " << rollNumber << std::endl;
        std::cout << "Name: " << name << std::endl;
        std::cout << "Age: " << age << std::endl;
    }
};

class StudentDatabase {
private:
    std::vector<Student> students;

public:
    void addStudent(const Student& student) {
        students.push_back(student);
    }

    void displayStudents() const {
        std::cout << "Student Database:" << std::endl;
        for (const Student& student : students) {
            student.displayInfo();
            std::cout << "------------------------" << std::endl;
        }
    }

    void searchStudent(int rollNumber) const {
        for (const Student& student : students) {
            if (student.getRollNumber() == rollNumber) {
                std::cout << "Student Found:" << std::endl;
                student.displayInfo();
                return;
            }
        }
        std::cout << "Student not found with Roll Number " << rollNumber << std::endl;
    }
};

class UserInterface {
private:
    StudentDatabase db;

public:
    void displayMenu() {
        std::cout << "Student Database Management System" << std::endl;
        std::cout << "1. Add Student" << std::endl;
        std::cout << "2. Search Student" << std::endl;
        std::cout << "3. Display All Students" << std::endl;
        std::cout << "4. Exit" << std::endl;
    }

    void addStudent() {
        int roll;
        std::string name;
        int age;

        std::cout << "Enter Roll Number: ";
        std::cin >> roll;
        std::cin.ignore(); // Clear newline character
        std::cout << "Enter Name: ";
        std::getline(std::cin, name);
        std::cout << "Enter Age: ";
        std::cin >> age;

        Student student(roll, name, age);
        db.addStudent(student);
        std::cout << "Student added successfully!" << std::endl;
    }

    void searchStudent() {
        int rollNumber;
        std::cout << "Enter Roll Number to search: ";
        std::cin >> rollNumber;
        db.searchStudent(rollNumber);
    }

    void displayAllStudents() {
        db.displayStudents();
    }

    void run() {
        int choice;
        do {
            displayMenu();
            std::cout << "Enter your choice: ";
            std::cin >> choice;

            switch (choice) {
                case 1:
                    addStudent();
                    break;
                case 2:
                    searchStudent();
                    break;
                case 3:
                    displayAllStudents();
                    break;
                case 4:
                    std::cout << "Exiting the program." << std::endl;
                    break;
                default:
                    std::cout << "Invalid choice. Please try again." << std::endl;
            }

            if (choice != 4) {
                std::cout << "Press Enter to continue...";
                std::cin.ignore();
                std::cin.get();
            }

        } while (choice != 4);
    }
};

int main() {
    UserInterface ui;
    ui.run();

    return 0;
}
